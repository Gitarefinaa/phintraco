package com.example.myapplication.model

data class Ability(var id:String

)
