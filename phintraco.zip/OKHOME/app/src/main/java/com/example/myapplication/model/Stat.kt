package com.example.myapplication.model

data class Stat (var id:String)
