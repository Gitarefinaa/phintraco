package com.example.myapplication.model
import kotlinx.serialization.Serializable

@Serializable
data class PokemonList(
    val name: String? = null,
    val url: String? = null
)






