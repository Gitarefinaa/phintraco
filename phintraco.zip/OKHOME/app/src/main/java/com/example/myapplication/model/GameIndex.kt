package com.example.myapplication.model

data class GameIndex (var id:String)
