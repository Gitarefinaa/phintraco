package com.example.myapplication.model

data class Move (var id:String)
