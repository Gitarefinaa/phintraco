package com.example.myapplication


import android.app.Application

import dagger.hilt.android.HiltAndroidApp
import dagger.internal.DaggerGenerated
import javax.inject.Inject

@HiltAndroidApp
class PokemonApp : Application(){
}


