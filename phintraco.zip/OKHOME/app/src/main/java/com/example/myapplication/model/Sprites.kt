package com.example.myapplication.model

data class Sprites (var id:String)
