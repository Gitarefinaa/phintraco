package com.example.myapplication.model

data class HeldItem (var id:String)