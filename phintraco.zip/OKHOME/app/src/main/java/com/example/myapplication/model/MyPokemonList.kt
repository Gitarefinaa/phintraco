package com.example.myapplication.model
import kotlinx.serialization.Serializable
@Serializable
data class MyPokemonList(
    var id: Int ?,
    var id_pokemon  :Int?,
    var pokemon_name : String?

)






