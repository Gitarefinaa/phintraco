package com.example.myapplication.model

data class PokeType (var id:String)
