package com.example.myapplication

interface DaggerApplicationComponent {

}
